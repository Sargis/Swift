//: Playground - noun: a place where people can play

import UIKit
import XCTest

class Incrementor{
    
    /// текущий номер сохраняется
    var number:Int = 0
    /// наибольшее число может быть достигнуто **number**
    var maximumValue = Int.max
    
    /**
     Возвращает текущее число. В самом начале это ноль.
     - Returns: возврат **number**
     */
    func getNumber() ->Int{
        
        return self.number
    }
    
    /**
     * Увеличивает текущее число на один. После каждого вызова этого
     * метода getNumber() будет возвращать число на один больше.
     */
    
    func incrementNumber(){
        
        (self.number + 1)%self.maximumValue
    }
    
    /**
     setMaximumValue nkaragrutyun
     * Устанавливает максимальное значение текущего числа.
     * Когда при вызове **incrementNumber()** текущее число достигает
     * этого значения, оно обнуляется, т.е. **getNumber()** начинает
     * снова возвращать ноль, и снова один после следующего
     * вызова **incrementNumber()** и так далее.
     * По умолчанию максимум -- максимальное значение Int.
     * Если при смене максимального значения число резко начинает
     * превышать максимальное значение, то число надо обнулить.
     * Нельзя позволять установить тут число меньше нуля.
     - parameter maximumValue: новое максимальное число
     */
    
    func setMaximumValue(maximumValue:Int){
        
        assert(maximumValue > 0, "максимальное значение не может быть меньше или равно нулю.")
        print(maximumValue)
        self.maximumValue = maximumValue
        self.number = self.number*(self.number<=maximumValue).hashValue
    }

}

///Test
class IncrementorTest{
    
    func getNumber(){
        
        let testIncrementor = Incrementor()
        let testingValue = testIncrementor.getNumber()
        XCTAssertEqual(0, testingValue, "тест прошел")
    }
   
    func incrementNumber(){
        
        let testIncrementor = Incrementor()
        testIncrementor.incrementNumber()
        let testingValue = testIncrementor.getNumber()
        XCTAssertEqual(1, testingValue, "тест прошел")
    }
    
    func testGetMaximumValue() {
        
        let testIncrementor = Incrementor()
        for _ in 0..<100_000_00{
            testIncrementor.incrementNumber()
        }
        
        let testingValue = testIncrementor.getNumber()
        XCTAssertEqual(0, testingValue, "тест прошел")
    }
}


